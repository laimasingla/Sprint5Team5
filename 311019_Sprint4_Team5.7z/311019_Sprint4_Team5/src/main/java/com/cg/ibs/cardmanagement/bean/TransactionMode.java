
package com.cg.ibs.cardmanagement.bean;

public enum TransactionMode {


	ONLINE, CASH;
}

