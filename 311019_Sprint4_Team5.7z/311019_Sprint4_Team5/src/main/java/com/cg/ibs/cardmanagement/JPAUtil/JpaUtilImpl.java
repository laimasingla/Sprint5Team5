package com.cg.ibs.cardmanagement.JPAUtil;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JpaUtilImpl {
	
	
	private static EntityManagerFactory entityManagerFactory;
	private static EntityManager entityManager;

	static {
		entityManagerFactory = Persistence.createEntityManagerFactory("cardmanagement");
	}
	
	public static EntityManager getEntityManger() {
		
		if(null==entityManager || (!entityManager.isOpen())) {
			entityManager=entityManagerFactory.createEntityManager();
		}
		return entityManager;
	}
	
	public static EntityTransaction getTransaction() {
		return getEntityManger().getTransaction();
	}

}
