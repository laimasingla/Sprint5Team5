package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface BankService {

	public void setQueryStatus(String queryId, String newStatus, String remarks) throws IBSException;

	

	public String getNewQueryStatus(int newQueryStatus) throws IBSException;



	public void getNewDC(String queryId) throws IBSException;

	public void upgradeCC(String queryId) throws IBSException;

	public List<CaseIdBean> viewNewDebitQueries() throws IBSException;

	public List<CaseIdBean> viewNewCreditQueries() throws IBSException;

	public List<CaseIdBean> viewDebitUpgradeQueries() throws IBSException;

	public List<CaseIdBean> viewCreditUgradeQueries() throws IBSException;

	public List<CaseIdBean> viewDebitMismatchQueries() throws IBSException;

	public List<CaseIdBean> viewCreditMismatchQueries() throws IBSException;

	public boolean getBlockInput(int blockInput, BigInteger debitCardNumber) throws IBSException;

	public boolean getBlockInputCredit(int blockInput, BigInteger creditCardNumber) throws IBSException;



	public List<CreditCardTransaction> getCreditMismatchTransaction(BigInteger transactionId) throws IBSException;

	public boolean checkMismatchDebit(String queryId) throws IBSException;

	public List<DebitCardTransaction> getDebitMismatchTransaction(BigInteger mismatchTransactionId) throws IBSException;

	BigInteger getDebitTransactionId(String queryId) throws IBSException;

	public BigInteger getCreditTransactionId(String queryId) throws IBSException;

	boolean checkMismatchCredit(String queryId) throws IBSException;
}