package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.ibs.cardmanagement.JPAUtil.JpaUtilImpl;
import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

@Repository
public class DebitCardDaoImpl implements DebitCardDao {
	private static Logger logger = Logger.getLogger(DebitCardDaoImpl.class);
	private EntityManager entityManager;
	private EntityTransaction entityTransaction;

	public DebitCardDaoImpl() {
		entityManager = JpaUtilImpl.getEntityManger();
		entityTransaction = JpaUtilImpl.getTransaction();
	}

	@Override
	public BigInteger getAccountNumber(BigInteger debitCardNumber) throws IBSException {
		logger.info("entered into getAccountNumber method of DebitCardDaoImpl class");
		BigInteger accountNum = null;
		try {
			TypedQuery<BigInteger> query = entityManager.createQuery(
					"select a.accountNumber from DebitCardBean d INNER JOIN d.accountBeanObject a where d.cardNumber=:cardNum",
					BigInteger.class);
			query.setParameter("cardNum", debitCardNumber);
			accountNum = query.getSingleResult();

		} catch (NoResultException e) {
			logger.error(e);
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);

		}
		return accountNum;

	}

	@Override
	public List<DebitCardBean> viewAllDebitCards() throws IBSException {
		logger.info("entered into viewAllDebitCards method of DebitCardDaoImpl class");

		TypedQuery<DebitCardBean> debitQuery = entityManager.createQuery(SqlQueries.SELECT_DATA_FROM_DEBIT_CARD,
				DebitCardBean.class);
		return debitQuery.getResultList();

	}

	@Override
	public void actionANDC(DebitCardBean bean) throws IBSException {
		logger.info("entered into actionANDC method of DebitCardDaoImpl class");
		try {
			entityTransaction.begin();
			entityManager.persist(bean);
			entityTransaction.commit();
		} catch (RollbackException e) {
		}
	}

	@Override
	public String getdebitCardType(BigInteger debitCardNumber) throws IBSException {
		logger.info("entered into getDebitCardType method of DebitCardDaoImpl class");
		String cardType = null;
		try {
			TypedQuery<String> query = entityManager.createQuery(
					"select d.cardType from DebitCardBean d where d.cardNumber=:debitCardNum", String.class);
			query.setParameter("debitCardNum", debitCardNumber);
			cardType = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}
		return cardType;

	}

	@Override
	public boolean verifyDebitCardNumber(BigInteger debitCardNum) throws IBSException {
		logger.info("entered into verifyDebitCardNumber method of DebitCardDaoImpl class");
		boolean result = false;
		try {
			DebitCardBean d = entityManager.find(DebitCardBean.class, debitCardNum);
			if (d != null)
				result = true;
		} catch (NullPointerException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}
		return result;

	}

	@Override
	public String getDebitCardStatus(BigInteger debitCardNumber) throws IBSException {
		logger.info("entered into getDebitCardStatus method of DebitCardDaoImpl class");
		TypedQuery<String> query = entityManager
				.createQuery("select d.cardStatus from DebitCardBean d where d.cardNumber=:debitCardNum", String.class);
		query.setParameter("debitCardNum", debitCardNumber);
		String query1 = null;
		try {
			query1 = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.CARD_BLOCK_MESSAGE);
		}
		return query1;
	}

	@Override
	public BigInteger getDMAccountNumber(BigInteger debitCardNumber) throws IBSException {
		logger.info("entered into getDMAccountNumber method of DebitCardDaoImpl class");
		TypedQuery<BigInteger> query = entityManager.createQuery(
				"select a.accountNumber from DebitCardBean d join d.accountBeanObject  a where d.cardNumber=:debitCardNum",
				BigInteger.class);
		query.setParameter("debitCardNum", debitCardNumber);
		BigInteger query1 = null;
		try {
			query1 = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_ACCOUNT_EXIST);
		}
		return query1;

	}

	@Override
	public void actionUpgradeDC(String queryId) throws IBSException {
		String type = null;
		CaseIdBean caseIdBean = null;
		BigInteger cardNum = null;
		DebitCardBean cardBean = null;
		logger.info("entered into actionUpgradeDC method of DebitCardDaoImpl class");
		try {
			TypedQuery<CaseIdBean> query = entityManager
					.createQuery("select d from CaseIdBean d where d.caseIdTotal =:queryid", CaseIdBean.class);
			query.setParameter("queryid", queryId);
			caseIdBean = query.getSingleResult();
		} catch (NoResultException e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		cardNum = caseIdBean.getCardNumber();
		type = caseIdBean.getDefineServiceRequest();

		try {
			cardBean = entityManager.find(DebitCardBean.class, cardNum);
		} catch (NullPointerException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}

		cardBean.setCardType(type);
	}

	@Override
	public String getDebitCardPin(BigInteger debitCardNumber) throws IBSException {
		logger.info("entered into getDebitCardPin method of DebitCardDaoImpl class");
		String debitPin = null;
		try {
			TypedQuery<String> query = entityManager.createQuery(
					"select d.currentPin from DebitCardBean d where d.cardNumber=:debitCardNum", String.class);
			query.setParameter("debitCardNum", debitCardNumber);
			debitPin = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}

		return debitPin;
	}

	@Override
	public void setNewDebitPin(BigInteger debitCardNumber, String newPin) throws IBSException {
		logger.info("entered into setNewDebitPin method of DebitCardDaoImpl class");
		DebitCardBean cardBean = null;
		try {
			cardBean = entityManager.find(DebitCardBean.class, debitCardNumber);
			entityTransaction.begin();
			cardBean.setCurrentPin(newPin);
			entityTransaction.commit();
		} catch (NullPointerException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}

	}

	@Override

	public void blockDebitCard(BigInteger debitCardNumber) throws IBSException {

		DebitCardBean cardBean = null;

		try {
			cardBean = entityManager.find(DebitCardBean.class, debitCardNumber);
			entityTransaction.begin();
			cardBean.setCardStatus("Blocked");
			entityTransaction.commit();
		} catch (NullPointerException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);

		}

	}

	@Override
	public List<DebitCardBean> viewAllUnblockedDebitCards() throws IBSException {
		List<DebitCardBean> unblockedCards = null;
		try {
			TypedQuery<DebitCardBean> debitQuery = entityManager.createQuery(SqlQueries.SELECT_FROM_DEBIT_CARD,
					DebitCardBean.class);
			debitQuery.setParameter("num", "Active");
			unblockedCards = debitQuery.getResultList();
			if(unblockedCards.isEmpty())
				throw new IBSException("ALL cards are  Blocked!");
		} catch (NoResultException e) {

			throw new IBSException("ALL cards Blocked");
		}

		return unblockedCards;

	}

	@Override
	public List<AccountBean> getAccountList() throws IBSException {
		logger.info("entered into getAccountList method of DebitCardDaoImpl class");

		TypedQuery<AccountBean> accountQuery = entityManager.createQuery(SqlQueries.SELECT_DATA_FROM_ACCOUNT,
				AccountBean.class);
		return accountQuery.getResultList();

	}

	@Override

	public void activateDebitCard(BigInteger debitCardNumber) throws IBSException {

		DebitCardBean cardBean = null;

		try {

			cardBean = entityManager.find(DebitCardBean.class, debitCardNumber);

			entityTransaction.begin();

			cardBean.setCardStatus("Active");

			entityTransaction.commit();

		} catch (NullPointerException e) {

			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);

		}

	}

	@Override

	public void deactivateDebitCard(BigInteger debitCardNumber) throws IBSException {

		DebitCardBean cardBean = null;

		try {

			cardBean = entityManager.find(DebitCardBean.class, debitCardNumber);

			entityTransaction.begin();

			cardBean.setCardStatus("Inactive");

			entityTransaction.commit();

		} catch (NullPointerException e) {

			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);

		}

	}

	@Override
	public List<DebitCardBean> viewAllInactiveDebitCards() throws IBSException {
		List<DebitCardBean> unblockedCards = null;
		try {
			TypedQuery<DebitCardBean> debitQuery = entityManager.createQuery(SqlQueries.SELECT_FROM_DEBIT_CARD,
					DebitCardBean.class);
			debitQuery.setParameter("num", "Inactive");
unblockedCards=debitQuery.getResultList();
			
			
			if(unblockedCards.isEmpty())
				throw new IBSException("ALL cards are active!");
		} catch (NoResultException e) {
			
			throw new IBSException("ALL cards are active!");
		}
		
		return unblockedCards;
	}

}
