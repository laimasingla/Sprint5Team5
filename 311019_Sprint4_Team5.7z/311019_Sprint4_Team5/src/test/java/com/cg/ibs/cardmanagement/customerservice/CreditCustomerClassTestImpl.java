package com.cg.ibs.cardmanagement.customerservice;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import java.math.BigInteger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;
import com.cg.ibs.cardmanagement.service.CreditCustomer;
import com.cg.ibs.cardmanagement.service.CreditCustomerClassImpl;

class CreditCustomerClassTestImpl {

	
	   
	    CreditCustomer creditCustomer = new CreditCustomerClassImpl();

	 

	    
	    @Test
	    void requestCreditCardUpgrade() {
	        BigInteger creditCardNumber = new BigInteger("5189101213259898");
	        int myChoice = 2;
	        try {
	            assertNotNull(creditCustomer.requestCreditCardUpgrade(creditCardNumber, myChoice));
	            }
	            catch(IBSException e){
	                fail(e.getMessage());
	            }
	        }
	    @Test
	    void requestNonExistingCreditCardUpgrade(){
	        BigInteger creditCardNumber = new BigInteger("5189101213259896");
	        int myChoice = 5;
	        Assertions.assertThrows(IBSException.class, () -> {
	            creditCustomer.requestCreditCardUpgrade(creditCardNumber, myChoice);
	        });        
	    
	}
	    @Test
	    void applyNewCreditCard() {
	        BigInteger uci = new BigInteger("7894561239632587");
	        String newCardType = "Gold";
	        try {
	            assertNotNull(creditCustomer.applyNewCreditCard(newCardType, uci));
	            }
	            catch(IBSException e){
	                fail(e.getMessage());
	            }
	        }
	    @Test
	    void listAllCreditCards() {
	        try {
	            assertNotNull(creditCustomer.viewAllCreditCards());
	            }
	            catch(IBSException e){
	                fail(e.getMessage());
	            }
	        }

	/*
	 * @Test void listtransactions() { BigInteger creditCardNumber = new
	 * BigInteger("5189101213259898"); int days = 600; try {
	 * assertNotNull(creditCustomer.getCreditTrans(days, creditCardNumber)); }
	 * catch(IBSException e){ fail(e.getMessage()); } }
	 * 
	 * @Test void listtransactionsForNonExistingCard() { BigInteger creditCardNumber
	 * = new BigInteger("5189101213259895"); int days = 800;
	 * Assertions.assertThrows(IBSException.class, () -> {
	 * creditCustomer.getCreditTrans(days, creditCardNumber); }); }
	 */
//	    @Test
//	    void creditCardLost() {
//	        BigInteger creditCardNumber = new BigInteger("5189101213259898");
//	        try {
//	            assertNotNull(creditCustomer.requestCreditCardLost(creditCardNumber));
//	            }
//	            catch(IBSException e){
//	                fail(e.getMessage());
//	            }
//	        }
	    
}
