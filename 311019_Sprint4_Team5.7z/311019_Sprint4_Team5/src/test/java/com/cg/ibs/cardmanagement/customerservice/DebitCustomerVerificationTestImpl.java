package com.cg.ibs.cardmanagement.customerservice;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.math.BigInteger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;
import com.cg.ibs.cardmanagement.service.DebitCustomer;
import com.cg.ibs.cardmanagement.service.DebitCustomerClassImpl;
import com.cg.ibs.cardmanagement.service.DebitCustomerVerification;
import com.cg.ibs.cardmanagement.service.DebitCustomerVerificationImpl;

class DebitCustomerVerificationTestImpl {


	

	 DebitCustomer debitCustomer= new DebitCustomerClassImpl();
	    DebitCustomerVerification debitVerify = new DebitCustomerVerificationImpl();

	 


	 


	
	 

	    @Test
	    void verifyExistingDebitPin() {
	        BigInteger debitCardNumber = new BigInteger("5234567891012131");
	        String pin="2131";
	        try {
	        assertEquals(false, debitVerify.verifyDebitPin(pin, debitCardNumber));
	        }
	        catch(IBSException e){
	            fail(e.getMessage());
	        }
	    }
	        
	        @Test
	        void verifyNonExistingDebitPin() {
	            BigInteger debitCardNumber = new BigInteger("5234567891012132");
	            String pin="2138";
	            Assertions.assertThrows(IBSException.class, () -> {
	                debitVerify.verifyDebitPin(pin, debitCardNumber);
	            });
	            
	    }
	      
	    
	/*
	 * @Test void verifyDebitCardStatus() { BigInteger debitCardNumber = new
	 * BigInteger("5234567891012131"); try {
	 * assertNotNull(debitVerify.getDebitCardStatus(debitCardNumber)); }
	 * catch(IBSException e){ fail(e.getMessage()); }
	 * 
	 * }
	 * 
	 * @Test void verifyNonExistingDebitCardStatus() { BigInteger debitCardNumber =
	 * new BigInteger("5189101213259891");
	 * Assertions.assertThrows(IBSException.class, () -> {
	 * debitVerify.getDebitCardStatus(debitCardNumber); });
	 * 
	 * }
	 */
		}

