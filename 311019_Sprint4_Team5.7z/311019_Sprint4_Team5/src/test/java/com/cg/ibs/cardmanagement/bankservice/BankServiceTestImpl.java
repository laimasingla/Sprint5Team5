package com.cg.ibs.cardmanagement.bankservice;

//import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;

import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.dao.CustomerDao;
import com.cg.ibs.cardmanagement.dao.CustomerDaoImpl;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;
import com.cg.ibs.cardmanagement.service.BankService;
import com.cg.ibs.cardmanagement.service.BankServiceImpl;

public class BankServiceTestImpl {

	CustomerDao customerDao = new CustomerDaoImpl();
	BankService bankService = new BankServiceImpl();
	CaseIdBean caseIdObj = new CaseIdBean();










	/*
	 * @Test void viewTransactionsForCreditCard() { int days = 600; BigInteger
	 * creditCardNumber = new BigInteger("5189101213259898"); try {
	 * assertNotNull(bankService.getCreditTrans(days, creditCardNumber)); } catch
	 * (IBSException e) { fail(e.getMessage()); } }
	 * 
	 * @Test void checkInvalidNoOfDays() { int days = 1000;
	 * Assertions.assertThrows(IBSException.class, () -> {
	 * bankService.checkDays(days); });
	 * 
	 * }
	 */

	

	@Test
	void getNewQueryStatusForValidInput() {
		int newQueryStatus = 2;
		try {
			assertEquals("In Process", bankService.getNewQueryStatus(newQueryStatus));
		} catch (IBSException e) {
			fail(e.getMessage());
		}
	}

}